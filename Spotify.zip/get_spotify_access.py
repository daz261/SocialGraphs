# -*- coding: utf-8 -*-
"""
Created on Sun Nov 21 11:58:24 2021

@author: Nikolaj
"""
import spotipy
import os
from Spotify.get_spotify_environment import set_spotify_environment

script_dir = os.getcwd()
spotify_keys_path = os.path.join(script_dir, 'Spotify\spotify_keys.txt')
# Set the client_id and client_secret environmental variables
set_spotify_environment(spotify_keys_path)

def refresh_spotify_access():
    token = spotipy.oauth2.SpotifyClientCredentials(client_id=os.getenv('CLIENT_ID'), client_secret=os.getenv('CLIENT_SECRET'))
    cache_token = token.get_access_token(as_dict=False)
    sp = spotipy.Spotify(cache_token)
    return sp,cache_token