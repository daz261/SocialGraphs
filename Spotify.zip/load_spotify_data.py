from tqdm import tqdm
from Spotify.get_spotify_access import refresh_spotify_access
import pandas as pd


def search_album_id(list_of_albums):
    # make sure spotify access token is up-to-date
    sp,_ = refresh_spotify_access()
    
    failed_list = []
    album_ids = []
    for album in tqdm(list_of_albums):
        # for each album name find all albums search results
        results = sp.search(q = "album:" + album, type = "album")
        try:
            # get the first album from the search results  (0 index is the top search result) and find its uri
            album_id = results['albums']['items'][0]['uri']
            album_ids.append(album_id)
        except:
            # Save the album names that didn't have any search results
            failed_list.append(album)
    return album_ids


def analyze_albums(album_ids):    
    # Create empty dataframe
    album_features_list = ["album","artists","track_names","track_ids","popularity","danceability","energy","key","loudness","mode", "speechiness","instrumentalness","liveness","valence","tempo", "duration_ms","time_signature"]
    all_albums_df = pd.DataFrame(columns = album_features_list)
    
    # Loop through every album in the list of albums, extract features and append the features to the all_albums_df
    for idx,album_id in tqdm(enumerate(album_ids)):
        # make sure spotify access token is up-to-date
        sp,_ = refresh_spotify_access()
        try:
            # Create empty dict
            album_features = {}
    
            album = sp.album(album_id)
            album_tracks = album['tracks']['items']
            
            # Get metadata from the album
            album_features['album'] = [album['name'] for _ in range(len(album_tracks))]
            album_features['artists'] = [[artist['name'] for artist in album['artists']]
                                         for _ in range(len(album_tracks))]
            album_features['track_names'] = [track['name'] for track in album_tracks]
            album_features['track_ids'] = [track['id'] for track in album_tracks]
            album_features['popularity'] = [album['popularity']  for _ in range(len(album_tracks))]
            # get list of dicts with audio features for each song
            audio_features = [sp.audio_features(track_id)[0]
                              for track_id in album_features['track_ids']]
            
            # get list for each audio feature
            for feature in album_features_list[5:]:
                album_features[feature] = [track[feature] for track in audio_features]
                    # Concat the dfs
            album_df = pd.DataFrame(album_features)
            all_albums_df = pd.concat([all_albums_df, album_df], ignore_index = True)
        except:
            continue
    return all_albums_df


def analyze_album(album_id, as_df = False):    
    # make sure spotify access token is up-to-date
    sp,_ = refresh_spotify_access()
    
    album_features_list = ["album","artists","track_name","track_id","popularity","danceability","energy","key","loudness","mode", "speechiness","instrumentalness","liveness","valence","tempo", "duration_ms","time_signature"]
    
    album = sp.album(album_id)
    album_tracks = album['tracks']['items']
    
    album_analyzed = []
    for track in album_tracks:
        # Create empty dict
        track_features = {}
        # Get metadata from the album
        track_features['album'] = album['name']
        track_features['artists'] = tuple([artist['name'] for artist in album['artists']])
        track_features['track_name'] = track['name']
        track_features['track_id'] = track['id']
        track_features['popularity'] = album['popularity']
        # get list of dicts with audio features for each song
        audio_features = sp.audio_features(track_features['track_id'])[0]
        # get list for each audio feature
        for feature in album_features_list[5:]:
            track_features[feature] = audio_features[feature]
        
        album_analyzed.append(track_features)
    # make the df
    if as_df == True:
        result = pd.DataFrame(album_analyzed, columns = album_features_list) 
    else:
        result = album_analyzed
    return result

def analyze_album_list(album_ids): 
    album_features_list = ["album","artists","track_name","track_id","popularity","danceability","energy","key","loudness","mode", "speechiness","instrumentalness","liveness","valence","tempo", "duration_ms","time_signature"]
    albums_analyzed = []
    # Loop through every album in the dict and analyze it
    for album_id in tqdm(album_ids):
        try:
            album_analyzed = analyze_album(album_id)
            albums_analyzed += album_analyzed
        except:
            continue
    albums_df = pd.DataFrame(albums_analyzed, columns=album_features_list)
    return albums_df


"""
import json
#Load albums_ids
with open('album_ids_list.txt') as x:
    album_ids = json.load(x)
    
df = analyze_albums(album_ids)
"""
# keep available_markets, genres? (empty), images, popularity, release_date, release_date_precision